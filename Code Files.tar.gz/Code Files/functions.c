#include <stdio.h>
void display();
int main()
{

    int a;
    printf("Initializing display function\n");
    display();
    printf("Display Function Works\n");
    return 0;
}

void display()
{
    printf("This is display \n");
}
