# include<stdio.h>

int main(){
    char str[]= "Afaq";
    
    return 0;
}