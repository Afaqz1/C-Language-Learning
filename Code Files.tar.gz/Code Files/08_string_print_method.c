# include<stdio.h>

int main(){
    char *ptr = "Afaq Iftikhar";
    printf("%s", ptr);
    return 0;
}