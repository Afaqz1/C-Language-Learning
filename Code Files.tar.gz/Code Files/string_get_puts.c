# include<stdio.h>

int main(){
    char s[34];
    
    gets(s);
    puts(s);
    return 0;
}