# include<stdio.h>
#include<string.h>
struct employee{
    int code;
    float salary;
    char name[10];
};

int main(){
    struct employee afaq = {100, 342.2, "Afaq"};
    

    return 0;
}
