# include<stdio.h>

int main(){
    int marks[4];
    marks[0] = 34;
    marks[1] = 40;
    marks[2] = 56;
    marks[3] = 45;
    
    return 0;
}