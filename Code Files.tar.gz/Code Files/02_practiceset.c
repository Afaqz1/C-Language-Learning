#include <stdio.h>

int main()
{
    int a;
    int b = a;
    int v = 3 ^ 3;
    char dt = '2';
    
    printf("%d", v); 
    return 0;
}