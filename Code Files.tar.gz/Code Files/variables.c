#include <stdio.h>

int main()
{

    int a = 4;

    float b = 8.5;

    char c = 'u';
    printf("The value of a is %d \n", a);
    printf("The value of b is %f \n", b);
    printf("The value of c is %c \n", c);
    printf("Sum of a and a is %d \n", a + a);
    return 0;
} 